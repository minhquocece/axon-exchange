import { Component, OnInit } from '@angular/core';

import { Advert } from './advert/advert.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  adverts: Advert[] = [
  	new Advert(0, 'EUROBIKE Road Bike EURXC550 21', 100, 'Wheels Road Bicycle Dual Disc Brake Bicycle', 'https://images-na.ssl-images-amazon.com/images/I/51of2NapY9L._AC_US218_.jpg', 'EUROBIKE'),
  	new Advert(1, 'SE Bikes So Cal Flyer Grounds 24 BMX Bike', 400, 'Limited Edition City Grounds Colorway', 'https://images-na.ssl-images-amazon.com/images/I/51byvPONHaL._AC_US218_.jpg', "SE Bikes")
  ];
  newAdvert: Advert;
  loadedAdvert: Advert;
  loadedAnotherAdvert: Advert;
  // start: boolean;

  // advert = this.adverts[this.loadedAdvert];

  constructor() {
  	// this.start = true;
  	// console.log(this.adverts.length)
  	let id = Math.floor(Math.random()*(99)+2);
  	while (!this.onCheckId(id)) {
  		id = Math.floor(Math.random()*(99)+2);
  	}
  	this.newAdvert = new Advert(id, '', '', '', '', '');
  }

  ngOnInit() {
  }

  onAddAdvert(advert: Advert){
  	let id = Math.floor(Math.random()*(99)+2);
  	while (!this.onCheckId(id)) {
  		id = Math.floor(Math.random()*(99)+2);
  	}
   	this.loadedAdvert = new Advert(id, '', '', '', '', '');
   	let check = true;
  	this.adverts.map(item => {
  		if ( advert.id === item.id ) return check = false;
  		// console.log(item.id);
  	});
  	if (check) {
  		this.adverts.push(advert);
  	}
  }
  onDeleteAdvert(advert: Advert) {
  	let newAdverts = [];
  	this.adverts = this.adverts.filter(item => item.id !== advert.id); 	
  	// this.adverts = newAdverts;
  	console.log(this.adverts);
  }

  onCheckId(id: number) {
  	this.adverts.map(item => {
  		if ( id === item.id ) return false;
  	});  	
  	return true;
  }
}
