export class Advert {
	public id: number;
	public heading: string;
	public pricing: number;
	public description: string;
	public imagePath: string;
	public origin: string;

	constructor(id: number, heading: string, pricing: number, desc: string, imagePath: string, origin: string) {
		this.id = id;
		this.heading = heading;
		this.pricing = pricing;
		this.description = desc;
		this.imagePath = imagePath;
		this.origin = origin;
	}
}