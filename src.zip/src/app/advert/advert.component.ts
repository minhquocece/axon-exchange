import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

import { Advert } from './advert.model';


@Component({
  selector: 'app-advert',
  templateUrl: './advert.component.html',
  styleUrls: ['./advert.component.css']
})
export class AdvertComponent implements OnInit {
  @Input('advert') advert: Advert;
  @Output() advertSelected = new EventEmitter<Advert>();


  constructor() { 
  }

  ngOnInit() {
  }

  onSelect(advert: Advert) {
	this.advertSelected.emit(advert);
  }

}
