import { Component, OnInit, Output, EventEmitter } from '@angular/core';

import { Advert } from '../advert.model';

@Component({
  selector: 'app-advert-new',
  templateUrl: './advert-new.component.html',
  styleUrls: ['./advert-new.component.css']
})
export class AdvertNewComponent implements OnInit {
  // @Output() advertCreated = new EventEmitter<Advert>();

  constructor() { }

  ngOnInit() {
  }

 //  onSelect() {
 //  	// const newAdvert = new Advert(1, heading, pricing, description, imagePath, origin);
	// this.advertSelected.emit(newAdvert);  	
 //  }
}
