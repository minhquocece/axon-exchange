import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

import { Advert } from '../advert.model';

@Component({
  selector: 'app-advert-detail',
  templateUrl: './advert-detail.component.html',
  styleUrls: ['./advert-detail.component.css']
})
export class AdvertDetailComponent implements OnInit {	
  @Input('advert') advert: Advert;
  @Output() advertSelected = new EventEmitter<Advert>();
  

  constructor() { 
  }

  ngOnInit() {
  }

  onSelect(advert: Advert) {
	this.advertSelected.emit(advert);
  }
}
